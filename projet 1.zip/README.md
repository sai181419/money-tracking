# Money Tracker

A personal income and expense tracker with accounts, a dashboard, charts and data export.
Zero npm dependencies: Node.js built-ins only (HTTP server, SQLite, scrypt).

> Not financial advice. This is a record-keeping tool.

## Run it locally

Requires **Node.js 22.13 or newer** (`node --version`).

```bash
cd money-tracker
npm start            # or: node server.js
# open http://127.0.0.1:3000
```

The database file is created automatically at `data/moneytracker.db` from `schema.sql`. Nothing else to install.
Create an account, then use **Settings → Load demo data** to explore with clearly labelled example entries.

Run the automated checks (starts a throwaway server and database):

```bash
npm test
```

## Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port to listen on |
| `HOST` | `127.0.0.1` | Use `0.0.0.0` in containers / to expose on a network |
| `DB_PATH` | `./data/moneytracker.db` | SQLite file location (put it on persistent storage) |
| `NODE_ENV` | – | `production` turns on Secure cookies and HSTS |
| `TRUST_PROXY` | – | Set `1` behind a reverse proxy so login throttling sees real client IPs |
| `COOKIE_SECURE` | follows `NODE_ENV` | `1` / `0` to override |

## Deploy

**Always serve over HTTPS in production.** Secure cookies only work over HTTPS, and passwords must not cross the network in clear text.

### Option A: Docker (any host)

```bash
docker build -t money-tracker .
docker run -d --name money-tracker -p 3000:3000 -v money-data:/data money-tracker
```
Put a TLS-terminating proxy (Caddy, nginx, your host's load balancer) in front, and add `-e TRUST_PROXY=1`.

### Option B: Managed platform (Render, Railway, Fly.io…)

Deploy from the Dockerfile (or use `npm start` with Node 22+). Then:
1. Attach a **persistent disk/volume** and set `DB_PATH` to a file on it (the Dockerfile uses `/data`).
2. Set `NODE_ENV=production`, `HOST=0.0.0.0`, `TRUST_PROXY=1`.
3. Run **a single instance**: SQLite is a single-writer file database.

### Option C: A small Linux server

```bash
# as a service user, in /opt/money-tracker
NODE_ENV=production HOST=127.0.0.1 PORT=3000 TRUST_PROXY=1 node server.js
```
Run it under systemd, and let Caddy provide HTTPS automatically:
```
money.example.com {
    reverse_proxy 127.0.0.1:3000
}
```

### Backups
Copy the database with SQLite's online backup (safe while running): `sqlite3 moneytracker.db ".backup backup.db"`, or stop the app and copy the file. Users can also export their own data (CSV/JSON) from Settings.

## How it works

- **Passwords:** scrypt (N=32768, r=8) with a unique 16-byte random salt per user; constant-time comparison. Strong-password rules: 10+ characters with upper, lower, number and symbol, and not containing the username.
- **Sessions:** random 256-bit token in an `HttpOnly; SameSite=Strict` cookie (`Secure` in production). Only a SHA-256 hash is stored. Sessions last 14 days; logout deletes them.
- **Privacy:** every query on `entries` is scoped by the `user_id` from the session, never from the request. Other users' records return "not found".
- **Validation:** amounts (positive, ≤2 decimals, stored as integer cents), real calendar dates, category lists per type, note length, currency list: all enforced on the server and again by database `CHECK` constraints.
- **Hardening:** parameterised SQL only, text rendered with `textContent` (no HTML injection), strict Content-Security-Policy, cross-origin write blocking, login throttling, CSV formula-injection protection.
- **Deleting an account** removes the user, all sessions and all entries (`ON DELETE CASCADE`).

## Known limits

- `node:sqlite` is marked experimental by Node (it works fine; the API may change in future Node versions).
- Login throttling is in memory and resets on restart; with multiple server instances it would need a shared store.
- No password reset: there's no email on file by design. A forgotten password means a new account.
- Amounts support up to 2 decimals for every currency.
- The 1,000 most recent matching entries are listed; totals and charts always include everything in range.

## Project layout

```
server.js        API, auth, static files
schema.sql       database tables (run automatically)
public/          index.html, app.js, style.css (no build step)
test/smoke.js    end-to-end tests
Dockerfile       container image
```
