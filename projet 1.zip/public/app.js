'use strict';
(() => {
  // ---------- Small helpers ----------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const NS = 'http://www.w3.org/2000/svg';

  // Builds DOM nodes with textContent only (never innerHTML), so user text can't inject markup.
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }
  function s(tag, attrs, text) {
    const el = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) el.setAttribute(k, v);
    if (text != null) el.textContent = text;
    return el;
  }

  async function api(method, url, body) {
    const res = await fetch(url, {
      method, credentials: 'same-origin',
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = {};
    try { data = await res.json(); } catch { /* empty body */ }
    if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed.'), { status: res.status });
    return data;
  }

  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseDate = (str) => { const [y, m, d] = str.split('-').map(Number); return new Date(y, m - 1, d); };
  const cap = (str) => str.charAt(0).toUpperCase() + str.slice(1);

  const state = { me: null, meta: null, view: 'dashboard', period: 'month', offset: 0, from: '', to: '', category: '', type: '' };

  function money(cents, opts) {
    try {
      return new Intl.NumberFormat(undefined, { style: 'currency', currency: state.me.currency, ...opts }).format(cents / 100);
    } catch { return (cents / 100).toFixed(2); }
  }
  const signed = (cents) => (cents < 0 ? '−' : '') + money(Math.abs(cents));

  // ---------- Views ----------
  function showAuth() {
    state.me = null;
    $('#auth-view').hidden = false; $('#app-view').hidden = true; $('#nav').hidden = true;
  }
  function showApp(info) {
    state.me = info.user; state.meta = info.meta;
    $('#auth-view').hidden = true; $('#app-view').hidden = false; $('#nav').hidden = false;
    $('#demo-banner').hidden = !info.user.demo_count;
    const sel = $('#f-category'), cur = state.category;
    sel.replaceChildren(h('option', { value: '' }, 'All categories'),
      ...[...new Set([...info.meta.categories.expense, ...info.meta.categories.income])].map((c) => h('option', { value: c }, cap(c))));
    sel.value = cur;
    $('#s-currency').replaceChildren(...info.meta.currencies.map((c) => h('option', { value: c }, c)));
    $('#s-currency').value = info.user.currency;
    $('#s-budget').value = info.user.monthly_budget_cents ? (info.user.monthly_budget_cents / 100).toFixed(2) : '';
    setView(state.view);
  }
  function setView(v) {
    state.view = v;
    for (const name of ['dashboard', 'entries', 'settings']) $('#view-' + name).hidden = name !== v;
    $$('#nav .tab[data-view]').forEach((b) => b.setAttribute('aria-current', b.dataset.view === v ? 'page' : 'false'));
    $('#filters').hidden = v === 'settings';
    $('#add-btn').hidden = v === 'settings';
    if (v !== 'settings') refresh();
  }

  function onError(err) {
    if (err.status === 401) return showAuth();
    $('#filter-error').textContent = err.message;
  }

  // ---------- Date range ----------
  function getRange() {
    if (state.period === 'custom') return { from: state.from, to: state.to, label: 'Custom range' };
    const now = new Date(), fmt = (d, o) => d.toLocaleDateString(undefined, o);
    if (state.period === 'week') {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7) + 7 * state.offset);
      const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 6);
      const ps = new Date(start.getFullYear(), start.getMonth(), start.getDate() - 7), pe = new Date(start.getFullYear(), start.getMonth(), start.getDate() - 1);
      return { from: iso(start), to: iso(end), prevFrom: iso(ps), prevTo: iso(pe), label: `${fmt(start, { day: 'numeric', month: 'short' })} – ${fmt(end, { day: 'numeric', month: 'short', year: 'numeric' })}` };
    }
    if (state.period === 'month') {
      const start = new Date(now.getFullYear(), now.getMonth() + state.offset, 1);
      const end = new Date(start.getFullYear(), start.getMonth() + 1, 0);
      const ps = new Date(start.getFullYear(), start.getMonth() - 1, 1), pe = new Date(start.getFullYear(), start.getMonth(), 0);
      return { from: iso(start), to: iso(end), prevFrom: iso(ps), prevTo: iso(pe), label: fmt(start, { month: 'long', year: 'numeric' }) };
    }
    const y = now.getFullYear() + state.offset;
    return { from: `${y}-01-01`, to: `${y}-12-31`, prevFrom: `${y - 1}-01-01`, prevTo: `${y - 1}-12-31`, label: String(y) };
  }

  // ---------- Data loading ----------
  let loadToken = 0;
  async function refresh() {
    const r = getRange();
    $('#range-label').textContent = r.label;
    $('#prev').disabled = $('#next').disabled = state.period === 'custom';
    const err = $('#filter-error');
    err.textContent = '';
    if (!r.from || !r.to) { err.textContent = 'Choose a start and end date.'; return; }
    if (r.from > r.to) { err.textContent = 'The start date must be before the end date.'; return; }
    const qs = new URLSearchParams({ from: r.from, to: r.to });
    if (state.category) qs.set('category', state.category);
    const eqs = new URLSearchParams(qs);
    const sqs = new URLSearchParams(qs);
    if (r.prevFrom) { sqs.set('prev_from', r.prevFrom); sqs.set('prev_to', r.prevTo); }
    if (state.type) eqs.set('type', state.type);
    const token = ++loadToken;
    try {
      const [sum, ent] = await Promise.all([api('GET', '/api/summary?' + sqs), api('GET', '/api/entries?' + eqs)]);
      if (token !== loadToken) return; // a newer request superseded this one
      renderDashboard(sum);
      renderEntries(ent);
    } catch (e) { onError(e); }
  }

  // ---------- Dashboard ----------
  function delta(cur, prev, goodWhenUp) {
    if (!cur && !prev) return null;
    const d = cur - prev;
    if (d === 0) return h('span', { class: 'delta' }, 'Same as previous period');
    const good = goodWhenUp ? d > 0 : d < 0;
    return h('span', { class: 'delta ' + (good ? 'good' : 'bad') }, `${d > 0 ? '▲' : '▼'} ${money(Math.abs(d))} vs previous period`);
  }

  function renderDashboard(sum) {
    const t = sum.totals, p = sum.previous_totals;
    const rate = t.income > 0 ? Math.round((t.savings / t.income) * 100) : null;
    $('#totals').replaceChildren(
      h('div', { class: 'stat income' }, h('div', { class: 'stat-label' }, 'Income'), h('div', { class: 'stat-value' }, money(t.income)), delta(t.income, p.income, true)),
      h('div', { class: 'stat expense' }, h('div', { class: 'stat-label' }, 'Expenses'), h('div', { class: 'stat-value' }, money(t.expense)), delta(t.expense, p.expense, false)),
      h('div', { class: 'stat savings main' }, h('div', { class: 'stat-label' }, 'Savings (income − expenses)'),
        h('div', { class: 'stat-value' }, signed(t.savings)),
        h('div', { class: 'stat-sub' }, rate == null ? 'No income recorded in this period' : `You kept ${rate}% of your income`),
        delta(t.savings, p.savings, true)),
    );

    // Budget (only meaningful for a whole month with no category filter)
    const box = $('#budget'), budget = state.me.monthly_budget_cents;
    if (state.period === 'month' && budget > 0 && !state.category) {
      const pct = Math.round((t.expense / budget) * 100), left = budget - t.expense;
      const bar = h('div', { class: 'bar-track', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': Math.min(pct, 100), 'aria-label': 'Budget used' },
        h('div', { class: 'bar-fill ' + (pct > 100 ? 'over' : pct >= 80 ? 'warn' : '') }));
      bar.firstChild.style.width = Math.min(pct, 100) + '%';
      box.replaceChildren(h('h2', null, 'Monthly budget'), bar,
        h('p', null, `${money(t.expense)} of ${money(budget)} spent (${pct}%). `,
          left >= 0 ? `${money(left)} left.` : `Over budget by ${money(-left)}.`));
      box.hidden = false;
    } else box.hidden = true;

    // Highlights
    const items = [];
    const totalExp = t.expense;
    if (sum.by_category.length) {
      const top = sum.by_category[0];
      items.push(`Most spent on ${top.category}: ${money(top.total)} (${Math.round((top.total / totalExp) * 100)}% of expenses).`);
    } else items.push('No expenses recorded in this period.');
    if (sum.largest_expense) {
      const l = sum.largest_expense;
      items.push(`Largest single expense: ${money(l.amount_cents)} on ${l.category}${l.note ? ` (${l.note})` : ''}, ${parseDate(l.date).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}.`);
    }
    const prevLabel = `${parseDate(sum.previous.from).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })} – ${parseDate(sum.previous.to).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}`;
    if (t.savings !== p.savings || t.income || p.income || t.expense || p.expense) {
      const d = t.savings - p.savings;
      items.push(d === 0 ? `Savings match the previous period (${prevLabel}).`
        : `Savings are ${money(Math.abs(d))} ${d > 0 ? 'higher' : 'lower'} than the previous period (${prevLabel}: ${signed(p.savings)}).`);
    }
    if (p.expense > 0 && t.expense > 0) {
      const pc = Math.round(((t.expense - p.expense) / p.expense) * 100);
      if (pc !== 0) items.push(`Spending is ${Math.abs(pc)}% ${pc > 0 ? 'higher' : 'lower'} than the previous period.`);
    }
    $('#insights').replaceChildren(...items.map((x) => h('li', null, x)));

    renderCategories(sum.by_category, totalExp);
    renderTrend(sum);
  }

  function renderCategories(rows, total) {
    const el = $('#cat-chart');
    if (!rows.length) { el.replaceChildren(h('p', { class: 'empty' }, 'No expenses to chart for this period and filter.')); return; }
    el.replaceChildren(...rows.map((r) => {
      const pct = (r.total / total) * 100;
      const fill = h('div', { class: 'bar-fill c-' + r.category });
      fill.style.width = Math.max(pct, 1.5) + '%';
      return h('div', { class: 'cat-row' },
        h('div', { class: 'cat-head' }, h('span', null, cap(r.category)), h('span', { class: 'num' }, `${money(r.total)} · ${Math.round(pct)}%`)),
        h('div', { class: 'bar-track' }, fill));
    }));
  }

  function bucketList(from, to, gran) {
    const out = [];
    if (gran === 'day') {
      for (let d = parseDate(from); iso(d) <= to; d.setDate(d.getDate() + 1)) out.push(iso(d));
    } else {
      const f = parseDate(from), end = to.slice(0, 7);
      for (let d = new Date(f.getFullYear(), f.getMonth(), 1); iso(d).slice(0, 7) <= end; d.setMonth(d.getMonth() + 1)) out.push(iso(d).slice(0, 7));
    }
    return out;
  }

  function niceStep(range) {
    const p = 10 ** Math.floor(Math.log10(range)), n = range / p;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
  }

  function renderTrend(sum) {
    const el = $('#trend'), gran = sum.granularity;
    const keys = bucketList(sum.range.from, sum.range.to, gran);
    const map = Object.fromEntries(sum.series.map((x) => [x.bucket, x]));
    const inc = keys.map((k) => map[k]?.income || 0), exp = keys.map((k) => map[k]?.expense || 0);
    if (!inc.some(Boolean) && !exp.some(Boolean)) { el.replaceChildren(h('p', { class: 'empty' }, 'No entries to chart for this period and filter.')); return; }
    const labels = keys.map((k) => gran === 'day'
      ? parseDate(k).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })
      : parseDate(k + '-01').toLocaleDateString(undefined, { month: 'short', year: '2-digit' }));
    const series = [
      { name: 'Income', cls: 'income', values: inc },
      { name: 'Expenses', cls: 'expense', values: exp },
      { name: 'Savings', cls: 'savings', values: inc.map((v, i) => v - exp[i]) },
    ];

    const W = 480, H = 280, L = 54, R = 12, T = 14, B = 34;
    let min = Math.min(0, ...series.flatMap((x) => x.values)), max = Math.max(0, ...series.flatMap((x) => x.values));
    if (max === min) max = min + 100;
    const step = niceStep((max - min) / 4);
    min = Math.floor(min / step) * step; max = Math.ceil(max / step) * step;
    const n = keys.length;
    const x = (i) => (n === 1 ? L + (W - L - R) / 2 : L + ((W - L - R) * i) / (n - 1));
    const y = (v) => T + (H - T - B) * (1 - (v - min) / (max - min));

    const svg = s('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Line chart of income, expenses and savings over the selected period' });
    const ticks = Math.round((max - min) / step);
    for (let i = 0; i <= ticks; i++) {
      const v = min + i * step;
      svg.append(s('line', { x1: L, x2: W - R, y1: y(v), y2: y(v), class: v === 0 ? 'zero' : 'grid' }),
        s('text', { x: L - 6, y: y(v) + 4, 'text-anchor': 'end', class: 'axis' }, money(v, { notation: 'compact', maximumFractionDigits: 1 })));
    }
    const every = Math.ceil(n / 6);
    labels.forEach((lab, i) => {
      if (i % every === 0 || i === n - 1 && n < 8) svg.append(s('text', { x: x(i), y: H - 12, 'text-anchor': n === 1 ? 'middle' : i === 0 ? 'start' : 'middle', class: 'axis' }, lab));
    });
    for (const ser of series) {
      if (n > 1) svg.append(s('polyline', { class: 'line s-' + ser.cls, points: ser.values.map((v, i) => `${x(i)},${y(v)}`).join(' ') }));
      if (n <= 31) ser.values.forEach((v, i) => {
        const c = s('circle', { cx: x(i), cy: y(v), r: 3.5, class: 'dot s-' + ser.cls });
        c.append(s('title', {}, `${ser.name}, ${labels[i]}: ${signed(v)}`));
        svg.append(c);
      });
    }
    const legend = h('div', { class: 'legend' }, series.map((ser) => {
      const sw = s('svg', { width: 28, height: 10, 'aria-hidden': 'true' });
      sw.append(s('line', { x1: 0, x2: 28, y1: 5, y2: 5, class: 'line s-' + ser.cls }));
      return h('span', null, sw, ser.name);
    }));
    el.replaceChildren(svg, legend);
  }

  // ---------- Entries ----------
  function renderEntries(data) {
    const el = $('#entries-list'), rows = data.entries;
    if (!rows.length) {
      el.replaceChildren(h('p', { class: 'empty' }, 'No entries match these filters. Choose “Add entry” to record one, or load demo data in Settings to explore.'));
      return;
    }
    const body = h('tbody', null, rows.map((r) => h('tr', null,
      h('td', { 'data-label': 'Date' }, parseDate(r.date).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })),
      h('td', { 'data-label': 'Category' }, cap(r.category), r.is_demo ? h('span', { class: 'badge' }, 'Demo') : null),
      h('td', { 'data-label': 'Note', class: 'note' }, r.note || '—'),
      h('td', { 'data-label': 'Amount', class: 'num amt ' + r.type }, (r.type === 'income' ? '+' : '−') + money(r.amount_cents)),
      h('td', { class: 'row-actions' },
        h('button', { type: 'button', onclick: () => openEntry(r) }, 'Edit'),
        h('button', { type: 'button', class: 'linkish', onclick: () => removeEntry(r) }, 'Delete')))));
    el.replaceChildren(
      h('table', null, h('thead', null, h('tr', null, ['Date', 'Category', 'Note', 'Amount', ''].map((c) => h('th', { scope: 'col' }, c)))), body),
      data.truncated ? h('p', { class: 'empty' }, 'Showing the 1,000 most recent matching entries. Narrow the date range to see others.') : null);
  }

  async function removeEntry(r) {
    if (!confirm(`Delete this ${r.type} of ${money(r.amount_cents)} (${r.category})?`)) return;
    try { await api('DELETE', '/api/entries/' + r.id); await refresh(); } catch (e) { onError(e); }
  }

  // ---------- Entry dialog ----------
  const dlg = $('#entry-dialog'), form = $('#entry-form');
  let editingId = null;
  function fillCategories(type, selected) {
    form.category.replaceChildren(...state.meta.categories[type].map((c) => h('option', { value: c }, cap(c))));
    if (selected) form.category.value = selected;
  }
  function openEntry(entry) {
    editingId = entry ? entry.id : null;
    $('#entry-title').textContent = entry ? 'Edit entry' : 'Add entry';
    $('#entry-error').textContent = '';
    const type = entry ? entry.type : 'expense';
    form.type.value = type;
    fillCategories(type, entry && entry.category);
    form.amount.value = entry ? (entry.amount_cents / 100).toFixed(2) : '';
    form.date.value = entry ? entry.date : iso(new Date());
    form.note.value = entry ? entry.note : '';
    dlg.showModal();
    form.amount.focus();
  }
  $$('input[name=type]', form).forEach((r) => r.addEventListener('change', () => fillCategories(form.type.value)));
  $('#add-btn').addEventListener('click', () => openEntry(null));
  $('#entry-cancel').addEventListener('click', () => dlg.close());
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const btn = $('#entry-save'); btn.disabled = true;
    const body = { type: form.type.value, amount: form.amount.value, date: form.date.value, category: form.category.value, note: form.note.value };
    try {
      await (editingId ? api('PUT', '/api/entries/' + editingId, body) : api('POST', '/api/entries', body));
      dlg.close();
      await refresh();
    } catch (e) { if (e.status === 401) { dlg.close(); showAuth(); } else $('#entry-error').textContent = e.message; }
    finally { btn.disabled = false; }
  });

  // ---------- Filters & navigation ----------
  $('#period').addEventListener('change', (e) => {
    state.period = e.target.value; state.offset = 0;
    $('#custom-range').hidden = state.period !== 'custom';
    if (state.period === 'custom') {
      const r = { from: $('#from-date').value, to: $('#to-date').value };
      if (!r.from || !r.to) {
        const now = new Date();
        state.from = iso(new Date(now.getFullYear(), now.getMonth(), 1)); state.to = iso(now);
        $('#from-date').value = state.from; $('#to-date').value = state.to;
      }
    }
    refresh();
  });
  $('#from-date').addEventListener('change', (e) => { state.from = e.target.value; refresh(); });
  $('#to-date').addEventListener('change', (e) => { state.to = e.target.value; refresh(); });
  $('#prev').addEventListener('click', () => { state.offset--; refresh(); });
  $('#next').addEventListener('click', () => { state.offset++; refresh(); });
  $('#f-category').addEventListener('change', (e) => { state.category = e.target.value; refresh(); });
  $('#f-type').addEventListener('change', (e) => { state.type = e.target.value; refresh(); });
  $$('#nav .tab[data-view]').forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));

  // ---------- Settings ----------
  $('#settings-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const msg = $('#settings-msg'); msg.className = 'error'; msg.textContent = '';
    try {
      showApp(await api('PATCH', '/api/settings', { currency: $('#s-currency').value, monthly_budget: $('#s-budget').value.trim() || '0' }));
      msg.className = 'ok'; msg.textContent = 'Settings saved.';
    } catch (e) { msg.textContent = e.message; }
  });
  const setDemo = (method) => async () => {
    try { showApp(await api(method, '/api/demo')); } catch (e) { onError(e); }
  };
  $('#load-demo').addEventListener('click', setDemo('POST'));
  $('#remove-demo').addEventListener('click', setDemo('DELETE'));
  $('#banner-remove-demo').addEventListener('click', setDemo('DELETE'));
  $('#delete-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const msg = $('#delete-msg'); msg.textContent = '';
    if (!confirm('Permanently delete your account and all of your entries? This cannot be undone.')) return;
    try {
      await api('DELETE', '/api/account', { password: ev.target.password.value });
      ev.target.reset(); showAuth();
    } catch (e) { msg.textContent = e.message; }
  });
  $('#logout').addEventListener('click', async () => { try { await api('POST', '/api/logout'); } finally { showAuth(); } });

  // ---------- Auth forms ----------
  function authMode(register) {
    $('#login-form').hidden = register; $('#register-form').hidden = !register;
    $('#show-login').classList.toggle('on', !register); $('#show-register').classList.toggle('on', register);
    $('#show-login').setAttribute('aria-pressed', String(!register)); $('#show-register').setAttribute('aria-pressed', String(register));
  }
  $('#show-login').addEventListener('click', () => authMode(false));
  $('#show-register').addEventListener('click', () => authMode(true));

  const rules = { len: (p) => p.length >= 10, lower: (p) => /[a-z]/.test(p), upper: (p) => /[A-Z]/.test(p), digit: (p) => /\d/.test(p), sym: (p) => /[^A-Za-z0-9]/.test(p) };
  $('#reg-password').addEventListener('input', (e) => {
    for (const li of $$('#pw-rules li')) li.classList.toggle('met', rules[li.dataset.rule](e.target.value));
  });

  async function submitAuth(ev, url, extra) {
    ev.preventDefault();
    const f = ev.target, err = $('.error', f), btn = $('button[type=submit]', f);
    err.textContent = '';
    if (extra && f.password.value !== f.confirm.value) { err.textContent = 'The two passwords do not match.'; return; }
    btn.disabled = true;
    try {
      const info = await api('POST', url, { username: f.username.value, password: f.password.value });
      f.reset(); $$('#pw-rules li').forEach((li) => li.classList.remove('met'));
      state.view = 'dashboard'; showApp(info);
    } catch (e) { err.textContent = e.message; }
    finally { btn.disabled = false; }
  }
  $('#login-form').addEventListener('submit', (ev) => submitAuth(ev, '/api/login'));
  $('#register-form').addEventListener('submit', (ev) => submitAuth(ev, '/api/register', true));

  // ---------- Start ----------
  api('GET', '/api/me').then(showApp).catch(showAuth);
})();
