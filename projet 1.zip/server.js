'use strict';
/**
 * Money Tracker backend. Node.js 22.13+ only, no npm dependencies.
 * HTTP server + SQLite (node:sqlite) + scrypt password hashing + cookie sessions.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { DatabaseSync } = require('node:sqlite');
const scrypt = promisify(crypto.scrypt);

// ---------- Configuration ----------
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'moneytracker.db');
const PROD = process.env.NODE_ENV === 'production';
const COOKIE_SECURE = process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === '1' : PROD;
const TRUST_PROXY = process.env.TRUST_PROXY === '1'; // set when behind a reverse proxy
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_MS = 14 * 24 * 3600 * 1000;
const SCRYPT_OPTS = { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

const CATEGORIES = {
  expense: ['food', 'transport', 'housing', 'bills', 'shopping', 'health', 'entertainment', 'other'],
  income: ['salary', 'freelance', 'gifts', 'investments', 'other'],
};
const ALL_CATEGORIES = new Set([...CATEGORIES.expense, ...CATEGORIES.income]);
const CURRENCIES = ['USD', 'EUR', 'GBP', 'INR', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'SGD', 'AED', 'BRL', 'MXN', 'ZAR', 'SEK', 'NZD'];

// ---------- Database ----------
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// ---------- Helpers ----------
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(body));
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    if (!(req.headers['content-type'] || '').startsWith('application/json')) {
      return reject(new HttpError(415, 'Content-Type must be application/json.'));
    }
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 100_000) { reject(new HttpError(413, 'Request too large.')); req.destroy(); }
      else chunks.push(c);
    });
    req.on('end', () => {
      try {
        const v = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        if (v === null || typeof v !== 'object' || Array.isArray(v)) throw new Error();
        resolve(v);
      } catch { reject(new HttpError(400, 'Invalid JSON.')); }
    });
    req.on('error', reject);
  });
}

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

function setCookie(res, value, maxAgeSeconds) {
  res.setHeader('Set-Cookie',
    `sid=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSeconds}${COOKIE_SECURE ? '; Secure' : ''}`);
}

const clientIp = (req) =>
  (TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'unknown';

// Simple in-memory throttle for logins/registrations (resets on restart).
const attempts = new Map();
const WINDOW_MS = 15 * 60 * 1000;
const isLocked = (key, max) => { const a = attempts.get(key); return !!a && a.until > Date.now() && a.n >= max; };
function recordFail(key) {
  const now = Date.now();
  let a = attempts.get(key);
  if (!a || a.until <= now) a = { n: 0, until: now + WINDOW_MS };
  a.n++; attempts.set(key, a);
}
setInterval(() => { const now = Date.now(); for (const [k, a] of attempts) if (a.until <= now) attempts.delete(k); }, 60_000).unref();

// ---------- Validation ----------
function validDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s && s >= '1970-01-01' && s <= '2100-12-31';
}
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const daysBetween = (a, b) => Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 864e5);

/** Parses "12.34" into cents. Max 9 integer digits, max 2 decimals. */
function parseAmount(value, { allowZero = false } = {}) {
  const s = String(value ?? '').trim();
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(s)) throw new HttpError(400, 'Enter an amount like 12.50 (up to 2 decimals).');
  const [whole, frac = ''] = s.split('.');
  const cents = Number(whole) * 100 + Number((frac + '00').slice(0, 2));
  if (cents === 0 && !allowZero) throw new HttpError(400, 'Amount must be greater than zero.');
  return cents;
}

function passwordProblem(pw, username) {
  if (typeof pw !== 'string' || !pw) return 'Password is required.';
  if (pw.length < 10) return 'Password must be at least 10 characters.';
  if (pw.length > 128) return 'Password must be 128 characters or fewer.';
  if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/\d/.test(pw) || !/[^A-Za-z0-9]/.test(pw))
    return 'Password needs an upper-case letter, a lower-case letter, a number and a symbol.';
  if (pw.toLowerCase().includes(username.toLowerCase())) return 'Password must not contain your username.';
  return null;
}

function parseEntry(body) {
  const type = body.type;
  if (type !== 'income' && type !== 'expense') throw new HttpError(400, 'Type must be income or expense.');
  const amount_cents = parseAmount(body.amount);
  if (!validDate(body.date)) throw new HttpError(400, 'Enter a valid date (YYYY-MM-DD).');
  if (!CATEGORIES[type].includes(body.category)) throw new HttpError(400, 'Choose a valid category.');
  const note = body.note == null ? '' : String(body.note).trim();
  if (note.length > 200) throw new HttpError(400, 'Note must be 200 characters or fewer.');
  return { type, amount_cents, date: body.date, category: body.category, note };
}

// ---------- Passwords & sessions ----------
async function hashPassword(pw, saltHex) {
  const key = await scrypt(pw.normalize('NFKC'), Buffer.from(saltHex, 'hex'), 64, SCRYPT_OPTS);
  return key.toString('hex');
}
async function verifyPassword(pw, user) {
  const got = Buffer.from(await hashPassword(pw, user.salt), 'hex');
  const want = Buffer.from(user.password_hash, 'hex');
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}
const DUMMY_SALT = crypto.randomBytes(16).toString('hex'); // equalises timing for unknown usernames

function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
    .run(sha256(token), userId, Date.now() + SESSION_MS);
  setCookie(res, token, SESSION_MS / 1000);
}

function getUser(req) {
  const token = parseCookies(req).sid;
  if (!token) return null;
  const row = db.prepare(
    'SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?'
  ).get(sha256(token));
  if (!row) return null;
  if (row.expires_at < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    return null;
  }
  return row;
}

function sessionInfo(u) {
  const demo = db.prepare('SELECT COUNT(*) AS c FROM entries WHERE user_id = ? AND is_demo = 1').get(u.id).c;
  return {
    user: { username: u.username, currency: u.currency, monthly_budget_cents: u.monthly_budget_cents, demo_count: demo },
    meta: { categories: CATEGORIES, currencies: CURRENCIES },
  };
}

// ---------- Demo data ----------
function mulberry32(a) {
  return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function demoRows() {
  const rnd = mulberry32(42), rows = [], now = new Date();
  const pick = (a, b) => Math.round((a + rnd() * (b - a)) * 100);
  for (let k = 5; k >= 0; k--) {
    const y = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - k, 1)).getUTCFullYear();
    const mo = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - k, 1)).getUTCMonth();
    const last = new Date(Date.UTC(y, mo + 1, 0)).getUTCDate();
    const maxDay = k === 0 ? now.getUTCDate() : last;
    const add = (type, d, cat, cents, note) => {
      if (d <= maxDay) rows.push([type, cents, new Date(Date.UTC(y, mo, d)).toISOString().slice(0, 10), cat, 'Demo: ' + note]);
    };
    add('income', 1, 'salary', 320000, 'Monthly salary');
    if (rnd() < 0.5) add('income', 15, 'freelance', pick(150, 500), 'Side project');
    add('expense', 2, 'housing', 110000, 'Rent');
    add('expense', 5, 'bills', pick(55, 95), 'Electricity');
    add('expense', 8, 'bills', 4500, 'Internet');
    add('expense', 10, 'bills', 2500, 'Phone plan');
    for (let d = 1; d <= last; d += 3) add('expense', d, 'food', pick(12, 60), 'Groceries and meals');
    for (let d = 3; d <= last; d += 7) add('expense', d, 'transport', pick(10, 35), 'Fuel and transit');
    add('expense', 12, 'shopping', pick(30, 250), 'Clothes');
    add('expense', 24, 'shopping', pick(15, 90), 'Household items');
    if (rnd() < 0.6) add('expense', 18, 'health', pick(20, 80), 'Pharmacy');
    for (const d of [6, 14, 22, 27]) if (rnd() < 0.8) add('expense', d, 'entertainment', pick(10, 60), 'Outings');
  }
  return rows;
}

// ---------- Summary ----------
function summary(user, q) {
  const from = q.get('from'), to = q.get('to'), cat = q.get('category') || '';
  if (!validDate(from) || !validDate(to) || from > to) throw new HttpError(400, 'Choose a valid date range.');
  if (daysBetween(from, to) > 3660) throw new HttpError(400, 'Date range is too long (max 10 years).');
  if (cat && !ALL_CATEGORIES.has(cat)) throw new HttpError(400, 'Unknown category.');
  const catSql = cat ? ' AND category = ?' : '';
  const args = (f, t) => [user.id, f, t, ...(cat ? [cat] : [])];

  const totals = (f, t) => {
    const r = { income: 0, expense: 0 };
    for (const x of db.prepare(
      `SELECT type, SUM(amount_cents) AS s FROM entries WHERE user_id = ? AND date BETWEEN ? AND ?${catSql} GROUP BY type`
    ).all(...args(f, t))) r[x.type] = x.s;
    return { income: r.income, expense: r.expense, savings: r.income - r.expense };
  };

  const span = daysBetween(from, to) + 1;
  // The client sends the true previous week/month/year; otherwise use the same-length span just before.
  let prevFrom, prevTo;
  if (q.get('prev_from') && q.get('prev_to')) {
    prevFrom = q.get('prev_from'); prevTo = q.get('prev_to');
    if (!validDate(prevFrom) || !validDate(prevTo) || prevFrom > prevTo || daysBetween(prevFrom, prevTo) > 3660)
      throw new HttpError(400, 'Invalid comparison range.');
  } else {
    prevTo = addDays(from, -1); prevFrom = addDays(prevTo, -(span - 1));
  }
  const granularity = span <= 92 ? 'day' : 'month';
  const bucket = granularity === 'day' ? 'date' : 'substr(date, 1, 7)';

  const series = {};
  for (const x of db.prepare(
    `SELECT ${bucket} AS b, type, SUM(amount_cents) AS s FROM entries
     WHERE user_id = ? AND date BETWEEN ? AND ?${catSql} GROUP BY b, type`
  ).all(...args(from, to))) {
    (series[x.b] ||= { bucket: x.b, income: 0, expense: 0 })[x.type] = x.s;
  }

  return {
    range: { from, to }, previous: { from: prevFrom, to: prevTo },
    totals: totals(from, to), previous_totals: totals(prevFrom, prevTo),
    by_category: db.prepare(
      `SELECT category, SUM(amount_cents) AS total FROM entries
       WHERE user_id = ? AND type = 'expense' AND date BETWEEN ? AND ?${catSql}
       GROUP BY category ORDER BY total DESC`
    ).all(...args(from, to)),
    largest_expense: db.prepare(
      `SELECT date, category, note, amount_cents FROM entries
       WHERE user_id = ? AND type = 'expense' AND date BETWEEN ? AND ?${catSql}
       ORDER BY amount_cents DESC, date DESC LIMIT 1`
    ).get(...args(from, to)) || null,
    granularity,
    series: Object.values(series).sort((a, b) => (a.bucket < b.bucket ? -1 : 1)),
  };
}

// ---------- Routes ----------
function checkOrigin(req) {
  const origin = req.headers.origin;
  if (origin) {
    let host; try { host = new URL(origin).host; } catch { host = null; }
    if (host !== req.headers.host) throw new HttpError(403, 'Cross-origin request blocked.');
  }
}

const csvCell = (v) => {
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise spreadsheet formula injection
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

async function handleApi(req, res, url) {
  const m = req.method, p = url.pathname;
  if (m !== 'GET' && m !== 'HEAD') checkOrigin(req);

  // --- Public endpoints ---
  if (p === '/api/register' && m === 'POST') {
    const body = await readJson(req);
    const username = typeof body.username === 'string' ? body.username.trim() : '';
    if (!/^[A-Za-z0-9_.-]{3,30}$/.test(username))
      throw new HttpError(400, 'Username must be 3–30 characters: letters, numbers, dot, dash or underscore.');
    const problem = passwordProblem(body.password, username);
    if (problem) throw new HttpError(400, problem);
    const ipKey = 'reg:' + clientIp(req);
    if (isLocked(ipKey, 10)) throw new HttpError(429, 'Too many sign-ups from this address. Try again later.');
    if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) throw new HttpError(409, 'That username is taken.');
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = await hashPassword(body.password, salt);
    let id;
    try {
      id = db.prepare('INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)').run(username, hash, salt).lastInsertRowid;
    } catch { throw new HttpError(409, 'That username is taken.'); }
    recordFail(ipKey); // counts sign-ups per address
    createSession(res, id);
    return send(res, 201, sessionInfo(db.prepare('SELECT * FROM users WHERE id = ?').get(id)));
  }

  if (p === '/api/login' && m === 'POST') {
    const body = await readJson(req);
    const username = typeof body.username === 'string' ? body.username.trim() : '';
    const password = typeof body.password === 'string' ? body.password.slice(0, 128) : '';
    const ipKey = 'ip:' + clientIp(req), userKey = 'u:' + username.toLowerCase();
    if (isLocked(ipKey, 20) || isLocked(userKey, 5))
      throw new HttpError(429, 'Too many failed attempts. Try again in 15 minutes.');
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    const ok = user ? await verifyPassword(password, user) : (await hashPassword(password, DUMMY_SALT), false);
    if (!ok) { recordFail(ipKey); recordFail(userKey); throw new HttpError(401, 'Invalid username or password.'); }
    attempts.delete(userKey);
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
    createSession(res, user.id);
    return send(res, 200, sessionInfo(user));
  }

  if (p === '/api/logout' && m === 'POST') {
    const token = parseCookies(req).sid;
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    setCookie(res, '', 0);
    return send(res, 200, { ok: true });
  }

  // --- Authenticated endpoints: user id always comes from the session ---
  const user = getUser(req);
  if (!user) throw new HttpError(401, 'Please log in.');

  if (p === '/api/me' && m === 'GET') return send(res, 200, sessionInfo(user));

  if (p === '/api/settings' && m === 'PATCH') {
    const body = await readJson(req);
    if (!CURRENCIES.includes(body.currency)) throw new HttpError(400, 'Choose a supported currency.');
    const budget = parseAmount(body.monthly_budget ?? '0', { allowZero: true });
    db.prepare('UPDATE users SET currency = ?, monthly_budget_cents = ? WHERE id = ?').run(body.currency, budget, user.id);
    return send(res, 200, sessionInfo(db.prepare('SELECT * FROM users WHERE id = ?').get(user.id)));
  }

  if (p === '/api/account' && m === 'DELETE') {
    const body = await readJson(req);
    if (typeof body.password !== 'string' || !(await verifyPassword(body.password, user)))
      throw new HttpError(403, 'Password is incorrect.');
    db.prepare('DELETE FROM users WHERE id = ?').run(user.id); // cascades to entries and sessions
    setCookie(res, '', 0);
    return send(res, 200, { ok: true });
  }

  if (p === '/api/summary' && m === 'GET') return send(res, 200, summary(user, url.searchParams));

  if (p === '/api/entries' && m === 'GET') {
    const q = url.searchParams, where = ['user_id = ?'], args = [user.id];
    if (q.get('from')) { if (!validDate(q.get('from'))) throw new HttpError(400, 'Invalid from date.'); where.push('date >= ?'); args.push(q.get('from')); }
    if (q.get('to')) { if (!validDate(q.get('to'))) throw new HttpError(400, 'Invalid to date.'); where.push('date <= ?'); args.push(q.get('to')); }
    if (q.get('category')) { if (!ALL_CATEGORIES.has(q.get('category'))) throw new HttpError(400, 'Unknown category.'); where.push('category = ?'); args.push(q.get('category')); }
    if (q.get('type')) { if (!['income', 'expense'].includes(q.get('type'))) throw new HttpError(400, 'Unknown type.'); where.push('type = ?'); args.push(q.get('type')); }
    const rows = db.prepare(
      `SELECT id, type, amount_cents, date, category, note, is_demo FROM entries
       WHERE ${where.join(' AND ')} ORDER BY date DESC, id DESC LIMIT 1001`
    ).all(...args);
    return send(res, 200, { entries: rows.slice(0, 1000), truncated: rows.length > 1000 });
  }

  if (p === '/api/entries' && m === 'POST') {
    const e = parseEntry(await readJson(req));
    const r = db.prepare('INSERT INTO entries (user_id, type, amount_cents, date, category, note) VALUES (?, ?, ?, ?, ?, ?)')
      .run(user.id, e.type, e.amount_cents, e.date, e.category, e.note);
    return send(res, 201, { id: Number(r.lastInsertRowid) });
  }

  const em = p.match(/^\/api\/entries\/(\d{1,12})$/);
  if (em && m === 'PUT') {
    const e = parseEntry(await readJson(req));
    const r = db.prepare(
      'UPDATE entries SET type = ?, amount_cents = ?, date = ?, category = ?, note = ? WHERE id = ? AND user_id = ?'
    ).run(e.type, e.amount_cents, e.date, e.category, e.note, Number(em[1]), user.id);
    if (!r.changes) throw new HttpError(404, 'Entry not found.');
    return send(res, 200, { ok: true });
  }
  if (em && m === 'DELETE') {
    const r = db.prepare('DELETE FROM entries WHERE id = ? AND user_id = ?').run(Number(em[1]), user.id);
    if (!r.changes) throw new HttpError(404, 'Entry not found.');
    return send(res, 200, { ok: true });
  }

  if (p === '/api/demo' && m === 'POST') {
    db.exec('BEGIN');
    try {
      db.prepare('DELETE FROM entries WHERE user_id = ? AND is_demo = 1').run(user.id);
      const ins = db.prepare('INSERT INTO entries (user_id, type, amount_cents, date, category, note, is_demo) VALUES (?, ?, ?, ?, ?, ?, 1)');
      for (const r of demoRows()) ins.run(user.id, ...r);
      db.exec('COMMIT');
    } catch (err) { db.exec('ROLLBACK'); throw err; }
    return send(res, 200, sessionInfo(user));
  }
  if (p === '/api/demo' && m === 'DELETE') {
    db.prepare('DELETE FROM entries WHERE user_id = ? AND is_demo = 1').run(user.id);
    return send(res, 200, sessionInfo(user));
  }

  if (p === '/api/export' && m === 'GET') {
    const rows = db.prepare(
      'SELECT id, date, type, category, amount_cents, note, is_demo FROM entries WHERE user_id = ? ORDER BY date, id'
    ).all(user.id);
    const stamp = new Date().toISOString().slice(0, 10);
    if (url.searchParams.get('format') === 'json') {
      const data = JSON.stringify({
        exported_at: new Date().toISOString(), currency: user.currency,
        entries: rows.map((r) => ({ ...r, amount: (r.amount_cents / 100).toFixed(2), is_demo: !!r.is_demo })),
      }, null, 2);
      res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Disposition': `attachment; filename="money-tracker-${stamp}.json"`, 'Cache-Control': 'no-store' });
      return res.end(data);
    }
    const lines = ['id,date,type,category,amount,currency,note,demo_data'];
    for (const r of rows)
      lines.push([r.id, r.date, r.type, r.category, (r.amount_cents / 100).toFixed(2), user.currency, r.note, r.is_demo ? 'yes' : 'no'].map(csvCell).join(','));
    res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="money-tracker-${stamp}.csv"`, 'Cache-Control': 'no-store' });
    return res.end('\uFEFF' + lines.join('\r\n') + '\r\n');
  }

  throw new HttpError(404, 'Not found.');
}

// ---------- Static files ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch { res.writeHead(400); return res.end(); }
  if (rel === '/') rel = '/index.html';
  const file = path.join(PUBLIC_DIR, path.normalize(rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(req.method === 'HEAD' ? undefined : buf);
  });
}

// ---------- Server ----------
const server = http.createServer(async (req, res) => {
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  if (PROD) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (err) {
    if (res.headersSent) return res.end();
    if (err instanceof HttpError) return send(res, err.status, { error: err.message });
    console.error(err);
    send(res, 500, { error: 'Something went wrong on the server.' });
  }
});

server.listen(PORT, HOST, () => console.log(`Money Tracker running at http://${HOST}:${PORT}`));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => server.close(() => { db.close(); process.exit(0); }));
