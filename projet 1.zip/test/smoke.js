'use strict';
// End-to-end smoke test: starts the server on a temporary database and exercises the API.
const { spawn } = require('node:child_process');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');

const PORT = 3900 + Math.floor(Math.random() * 90);
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mt-'));
const DB = path.join(dir, 'test.db');
const base = `http://127.0.0.1:${PORT}`;
let passed = 0, failed = 0;
const check = (name, cond) => { cond ? passed++ : failed++; console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}`); };

async function call(method, url, body, cookie) {
  const res = await fetch(base + url, {
    method, redirect: 'manual',
    headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  const sc = res.headers.getSetCookie?.()[0];
  return { status: res.status, json, text, cookie: sc ? sc.split(';')[0] : null, setCookie: sc, headers: res.headers };
}

(async () => {
  const proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'server.js')],
    { env: { ...process.env, PORT, DB_PATH: DB, HOST: '127.0.0.1' }, stdio: 'ignore' });
  try {
    for (let i = 0; i < 50; i++) { try { await fetch(base + '/'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }

    const PW = 'Str0ng!Passw0rd';
    check('weak password rejected', (await call('POST', '/api/register', { username: 'alice', password: 'password' })).status === 400);
    check('password containing username rejected', (await call('POST', '/api/register', { username: 'alice', password: 'Alice!12345x' })).status === 400);
    const a = await call('POST', '/api/register', { username: 'alice', password: PW });
    check('register succeeds', a.status === 201 && a.cookie);
    check('cookie is HttpOnly + SameSite=Strict', /HttpOnly/.test(a.setCookie) && /SameSite=Strict/.test(a.setCookie));
    check('duplicate username (any case) rejected', (await call('POST', '/api/register', { username: 'ALICE', password: PW })).status === 409);
    check('entries require login', (await call('GET', '/api/entries')).status === 401);

    const A = a.cookie;
    const bad = [
      { type: 'expense', amount: '-5', date: '2026-01-01', category: 'food' },
      { type: 'expense', amount: '1.234', date: '2026-01-01', category: 'food' },
      { type: 'expense', amount: 'abc', date: '2026-01-01', category: 'food' },
      { type: 'expense', amount: '5', date: '2026-02-30', category: 'food' },
      { type: 'expense', amount: '5', date: '2026-01-01', category: 'salary' },
      { type: 'other', amount: '5', date: '2026-01-01', category: 'food' },
      { type: 'expense', amount: '5', date: '2026-01-01', category: 'food', note: 'x'.repeat(201) },
    ];
    let allRejected = true;
    for (const b of bad) if ((await call('POST', '/api/entries', b, A)).status !== 400) allRejected = false;
    check('invalid amounts, dates, categories, notes rejected', allRejected);

    const e1 = await call('POST', '/api/entries', { type: 'income', amount: '1000.50', date: '2026-03-01', category: 'salary', note: '=HYPERLINK("x")' }, A);
    const e2 = await call('POST', '/api/entries', { type: 'expense', amount: '250.25', date: '2026-03-05', category: 'food' }, A);
    check('valid entries created', e1.status === 201 && e2.status === 201);
    const sum = await call('GET', '/api/summary?from=2026-03-01&to=2026-03-31', null, A);
    check('totals + savings correct (income - expenses)', sum.json.totals.income === 100050 && sum.json.totals.expense === 25025 && sum.json.totals.savings === 75025);
    check('category breakdown', sum.json.by_category[0].category === 'food');
    const sumCat = await call('GET', '/api/summary?from=2026-03-01&to=2026-03-31&category=food', null, A);
    check('category filter works', sumCat.json.totals.income === 0 && sumCat.json.totals.expense === 25025);
    const prev = await call('GET', '/api/summary?from=2026-04-01&to=2026-04-30', null, A);
    check('previous period defaults to same-length span before', prev.json.previous.from === '2026-03-02' && prev.json.previous.to === '2026-03-31');
    const prev2 = await call('GET', '/api/summary?from=2026-04-01&to=2026-04-30&prev_from=2026-03-01&prev_to=2026-03-31', null, A);
    check('explicit previous calendar month used for comparison', prev2.json.previous_totals.savings === 75025);
    check('invalid comparison range rejected', (await call('GET', '/api/summary?from=2026-04-01&to=2026-04-30&prev_from=2026-05-01&prev_to=2026-03-31', null, A)).status === 400);

    const edit = await call('PUT', '/api/entries/' + e2.json.id, { type: 'expense', amount: '300', date: '2026-03-05', category: 'bills', note: 'edited' }, A);
    const list = await call('GET', '/api/entries?from=2026-03-01&to=2026-03-31', null, A);
    check('edit works', edit.status === 200 && list.json.entries.some((e) => e.amount_cents === 30000 && e.category === 'bills'));

    // Privacy: user B cannot see or touch user A's data
    const b = await call('POST', '/api/register', { username: 'bob', password: PW });
    const B = b.cookie;
    check("other user sees none of A's entries", (await call('GET', '/api/entries', null, B)).json.entries.length === 0);
    check("other user cannot edit A's entry", (await call('PUT', '/api/entries/' + e1.json.id, { type: 'income', amount: '1', date: '2026-01-01', category: 'salary' }, B)).status === 404);
    check("other user cannot delete A's entry", (await call('DELETE', '/api/entries/' + e1.json.id, null, B)).status === 404);
    check("A's entry still exists", (await call('GET', '/api/entries', null, A)).json.entries.length === 2);

    // Cross-origin writes blocked
    const xo = await fetch(base + '/api/entries', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: A, Origin: 'https://evil.example' }, body: JSON.stringify({ type: 'expense', amount: '1', date: '2026-01-01', category: 'food' }) });
    check('cross-origin POST blocked', xo.status === 403);

    const csv = await call('GET', '/api/export?format=csv', null, A);
    check('CSV export includes entries', csv.status === 200 && csv.text.includes('1000.50') && csv.text.includes('id,date,type'));
    check('CSV neutralises formula injection', csv.text.includes(`"'=HYPERLINK`) || csv.text.includes("'=HYPERLINK"));
    check('JSON export works', (await call('GET', '/api/export?format=json', null, A)).json.entries.length === 2);

    const set = await call('PATCH', '/api/settings', { currency: 'EUR', monthly_budget: '800' }, A);
    check('currency + budget saved', set.json.user.currency === 'EUR' && set.json.user.monthly_budget_cents === 80000);
    check('unsupported currency rejected', (await call('PATCH', '/api/settings', { currency: 'XXX', monthly_budget: '0' }, A)).status === 400);

    const demo = await call('POST', '/api/demo', null, A);
    const withDemo = await call('GET', '/api/entries', null, A);
    check('demo data loads and is flagged', demo.json.user.demo_count > 50 && withDemo.json.entries.some((e) => e.is_demo === 1 && e.note.startsWith('Demo:')));
    const rm = await call('DELETE', '/api/demo', null, A);
    check('demo data removed, real entries kept', rm.json.user.demo_count === 0 && (await call('GET', '/api/entries', null, A)).json.entries.length === 2);

    // Password storage
    const raw = new DatabaseSync(DB, { readOnly: true });
    const u = raw.prepare("SELECT password_hash, salt FROM users WHERE username = 'alice'").get();
    check('password stored as salted hash, not plain text', u.password_hash.length === 128 && u.salt.length === 32 && !u.password_hash.includes(PW));
    const sessions = raw.prepare('SELECT token_hash FROM sessions').all();
    check('session tokens stored hashed', sessions.every((s) => s.token_hash.length === 64 && !A.includes(s.token_hash)));
    raw.close();

    // Login, logout, throttling
    check('wrong password rejected', (await call('POST', '/api/login', { username: 'alice', password: 'Wrong!Passw0rd' })).status === 401);
    const login = await call('POST', '/api/login', { username: 'ALICE', password: PW });
    check('login works (case-insensitive username)', login.status === 200 && login.cookie);
    await call('POST', '/api/logout', null, login.cookie);
    check('logout invalidates session', (await call('GET', '/api/me', null, login.cookie)).status === 401);
    let last;
    for (let i = 0; i < 6; i++) last = await call('POST', '/api/login', { username: 'bob', password: 'Nope!Nope1234' });
    check('repeated failures are throttled (429)', last.status === 429);

    // Security headers + static
    const home = await call('GET', '/');
    check('serves frontend with CSP header', home.status === 200 && /default-src 'self'/.test(home.headers.get('content-security-policy')));
    check('path traversal blocked', (await fetch(base + '/..%2fserver.js')).status !== 200 && !(await (await fetch(base + '/../server.js')).text()).includes('createServer'));

    // Account deletion
    check('delete account needs correct password', (await call('DELETE', '/api/account', { password: 'Wrong!Passw0rd' }, A)).status === 403);
    check('delete account works', (await call('DELETE', '/api/account', { password: PW }, A)).status === 200);
    const raw2 = new DatabaseSync(DB, { readOnly: true });
    const left = raw2.prepare("SELECT (SELECT COUNT(*) FROM users WHERE username='alice') u, (SELECT COUNT(*) FROM entries WHERE user_id NOT IN (SELECT id FROM users)) orphans, (SELECT COUNT(*) FROM entries) total").get();
    check('account and all its entries removed (no orphans)', left.u === 0 && left.orphans === 0 && left.total === 0);
    raw2.close();
  } catch (err) { failed++; console.error('ERROR', err); }
  finally { proc.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
